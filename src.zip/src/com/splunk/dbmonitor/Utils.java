/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.splunk.dbmonitor;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
//import org.apache.http.client.entity.DecompressingEntity.
import java.util.*;
import java.io.*;
import org.apache.http.entity.StringEntity;
import org.json.JSONObject;
/**
 *
 * @author mwiser
 */
public class Utils {

public static boolean bdebug=false;

public static String decode(String enc) {
        String s = enc;
        String dec="";
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if       (c >= 'a' && c <= 'm') c += 13;
            else if  (c >= 'A' && c <= 'M') c += 13;
            else if  (c >= 'n' && c <= 'z') c -= 13;
            else if  (c >= 'N' && c <= 'Z') c -= 13;
            dec=dec+c;            
        }
        return dec;
    }
public static void heclog (String szSourceType, String szGUID,String szText,MainConfig mc)
{
    if (Utils.bdebug)
            System.out.println (new java.util.Date().toString()+" "+szSourceType+" "+szGUID+" "+szText);
    try
        {
        if (szSourceType.equals("error")||szSourceType.equals("data")||bdebug)
        {
        String url = "http://"+mc.szServerPort+"/services/collector";  
        //System.out.println (url);
          //      System.exit(0);
        HttpClient client = HttpClientBuilder.create().build();
	HttpPost post = new HttpPost(url);

	// add header
	post.setHeader("User-Agent", "DBMonitor");
        post.setHeader("Authorization", "Splunk "+mc.szHECToken);
        post.setHeader("Content-Type", "application/json");       
        //post.setHeader("sourcetype", szSourceType);
	
    	JSONObject json = new JSONObject();
        json.put("event", szText+", Spreadsheet="+mc.szSheet);   
        json.put("sourcetype", szSourceType);   
        StringEntity params = new StringEntity(json.toString());
        post.setEntity(params);
        try
        {

	HttpResponse response = client.execute(post);
	//System.out.println("Response Code : " 
          //      + response.getStatusLine().getStatusCode());

	BufferedReader rd = new BufferedReader(
	        new InputStreamReader(response.getEntity().getContent()));

	StringBuffer result = new StringBuffer();
	String line = "";
	while ((line = rd.readLine()) != null) {
		result.append(line);
	}
        rd.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        }
    }
        catch (Exception p)
    {
        p.printStackTrace();
    }
    }
    
    
    
    
    
}



